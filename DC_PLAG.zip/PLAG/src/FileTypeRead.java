
public abstract class FileTypeRead {
	
	private
	String path;
	
	public abstract String[] Read();

}
